# API escrita em fastapi com mongodb de backend

# Procedimento de Instalação

1 - Instalação do mongodb
2 - Start do mongodb
3 - Instalação dos requerimentos do python (requeriments.txt)
4 - Criar diretorio /opt/slacko-api/
5 - executar o script slacko-api.sh
